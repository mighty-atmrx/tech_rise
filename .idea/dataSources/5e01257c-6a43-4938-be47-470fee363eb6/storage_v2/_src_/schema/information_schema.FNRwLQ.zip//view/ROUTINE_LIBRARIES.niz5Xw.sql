create view ROUTINE_LIBRARIES as
select `cat`.`name`                                                 AS `ROUTINE_CATALOG`,
       `sch`.`name`                                                 AS `ROUTINE_SCHEMA`,
       `rtn`.`name`                                                 AS `ROUTINE_NAME`,
       `rtn`.`type`                                                 AS `ROUTINE_TYPE`,
       if((`lib`.`catalog` is null), `cat`.`name`, `lib`.`catalog`) AS `LIBRARY_CATALOG`,
       if((`lib`.`sch` is null), `sch`.`name`, `lib`.`sch`)         AS `LIBRARY_SCHEMA`,
       `lib`.`library_name`                                         AS `LIBRARY_NAME`,
       `lib`.`version`                                              AS `LIBRARY_VERSION`
from (((`mysql`.`routines` `rtn` join `mysql`.`schemata` `sch`
        on ((`rtn`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
       on ((`cat`.`id` = `sch`.`catalog_id`))) join json_table(get_dd_property_key_value(`rtn`.`options`, 'libraries'),
                                                               '$[*]'
                                                               columns (`catalog` varchar(64) character set utf8mb4 path '$.catalog', `sch` varchar(100) character set utf8mb4 path '$.schema', `library_name` varchar(100) character set utf8mb4 path '$.name', `version` varchar(100) character set utf8mb4 path '$.version')) `lib`)
where ((0 <> can_access_routine(`sch`.`name`, `rtn`.`name`, `rtn`.`type`, `rtn`.`definer`, false)) and
       (`rtn`.`options` is not null) and (json_valid(get_dd_property_key_value(`rtn`.`options`, 'libraries')) = 1));

